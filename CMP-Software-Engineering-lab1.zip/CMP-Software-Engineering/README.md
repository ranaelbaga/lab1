# CMP-Software-Engineering
Welcome to the Software Engineering Course Repository! This repository is designed to support students enrolled in CMP's Software Engineering course by providing a central hub for accessing course materials, lab assignments, and additional resources.
